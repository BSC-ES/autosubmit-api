__version__ = "1.0.0"
__author__ = 'Wilmer Uruchi'
__credits__ = 'Barcelona Supercomputing Center'