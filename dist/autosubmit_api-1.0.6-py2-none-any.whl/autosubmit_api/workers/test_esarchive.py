import autosubmit_api.experiment.common_requests as ExperimentUtils


def main():
    ExperimentUtils.test_esarchive_status()


if __name__ == "__main__":
    main()
